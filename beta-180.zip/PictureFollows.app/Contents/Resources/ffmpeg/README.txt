ffmpeg 9.0.2, built for Picture Follows by scripts/build_ffmpeg.sh, licensed under the GNU LGPL 2.1 or later
(LICENSE.LGPLv2.1.txt). No GPL or non-free parts. Universal: arm64 + x86_64, macOS 13.0 or later.
Source: https://ffmpeg.org/releases/ffmpeg-9.0.2.tar.xz (sha256 8c3850283eb25fa026482078a04051e0be17347b09ef81a0849bec15a96e002e), unmodified.
Configured with: --disable-everything --disable-autodetect --disable-gpl --disable-nonfree --disable-network --disable-doc --disable-debug --disable-programs --enable-ffmpeg --disable-avdevice --enable-static --disable-shared --enable-pthreads --enable-videotoolbox --enable-protocol=file,pipe --enable-demuxer=mov,mxf --enable-decoder=dnxhd,prores,h264,hevc,mpeg2video --enable-parser=dnxhd,h264,hevc,mpegvideo --enable-encoder=prores_videotoolbox --enable-muxer=mov --enable-filter=scale,format,null,buffer,buffersink
It runs as a separate program: Picture Follows starts it to make picture proxies from movies macOS can't decode.
