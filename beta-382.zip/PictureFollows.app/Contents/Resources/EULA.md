# PictureFollows License Agreement

Last updated: November 16, 2026

This is the agreement between you and James Wasserman, doing business as PictureFollows ("we", "us") for the PictureFollows app for macOS. By installing or using PictureFollows, you agree to it. If you don't agree, don't install or use it.

## 1. Your license

When you buy PictureFollows, we give you a personal, non-exclusive, non-transferable license to use it.

- **One person, two Macs.** You may activate your license on up to two Macs that you use yourself. To move it to a new Mac, deactivate it on an old one first.
- **Yours to keep.** The license is a one-time purchase. It doesn't expire and there's no subscription.
- **Updates are included.** Updates we release are free for license holders. We don't charge for upgrades.
- **Studios and facilities.** For licenses across several people or rooms, write to support@picturefollows.com.

## 2. The free trial

You can try PictureFollows without buying it. The trial gives you 30 free sends from Pro Tools to a supported editor. Send-backs and re-sends of the same clips don't count. When the 30 sends are used, the picture stops following until you buy a license. Nothing else changes, and your Pro Tools sessions are never touched.

## 3. What you may not do

- Share, sell, rent or lend your license key, or use it on more than two Macs.
- Get around the trial or the license check.
- Copy, change, decompile or reverse-engineer PictureFollows, except where the law allows it or where a component's own license allows it (see section 7).

## 4. Activation and privacy

PictureFollows checks your license key with our payment provider, Polar, when you activate it, and about once a week after that when you're online. It never stops working because you're offline or our provider can't be reached. Our Privacy Policy (picturefollows.com/privacy) explains what is sent and when.

## 5. Payments and refunds

Polar sells PictureFollows for us as the merchant of record and handles payment, tax and receipts. **Sales are final and we don't offer refunds**, because the 30-send trial is there for you to try the app first. Where the law where you live gives you a right to a refund, that right still applies.

## 6. Other companies' products

PictureFollows works alongside Pro Tools, iZotope RX, SpectraLayers, Acoustica and Video Sync. It is not made, endorsed or supported by Avid, iZotope, Native Instruments, Steinberg, Acon Digital or Non-Lethal Applications. Their names are their trademarks, used here only to say what PictureFollows works with. Updates to those products can change how PictureFollows works with them. We'll try to keep up, but we can't promise it.

## 7. Open-source components

PictureFollows includes open-source software, each under its own license. Copies of those licenses ship inside the app, in Contents/Resources:

- **FFmpeg** (LGPL version 2.1). You may replace it with your own build, and reverse-engineer PictureFollows as far as you need to debug such a change. To request the exact FFmpeg source and build script we used, write to support@picturefollows.com.
- **Sparkle** (MIT license), which delivers updates.

Nothing in this agreement limits your rights under those licenses.

## 8. No warranty

PictureFollows is provided "as is". We work hard to make it reliable, but we don't promise it will be free of errors or work with every setup, session or version of another company's product. Always keep your own backups and check your work before delivery.

## 9. Limit of liability

As far as the law allows, we aren't liable for indirect, incidental or consequential losses, such as lost work, lost data, lost income or missed deadlines. Our total liability for anything related to PictureFollows is limited to what you paid for it. Some places don't allow these limits, so they may not all apply to you.

## 10. Ending the license

If you break this agreement, your license ends. You must then stop using PictureFollows and delete it.

## 11. Changes

We may update this agreement. The current version is always at picturefollows.com/eula. A change won't take away a license you already bought.

## 12. The law

This agreement is governed by the laws of the State of California, USA, except where the law where you live says otherwise.

## Contact

support@picturefollows.com
